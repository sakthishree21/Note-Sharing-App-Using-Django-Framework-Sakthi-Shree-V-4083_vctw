from django.apps import AppConfig


class EnotesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'enotes'
